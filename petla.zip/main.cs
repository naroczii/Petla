using System;

class MainClass {
  public static void Main (string[] args) {
string[] tydzien = {"poniedzialek", "wtorek", "sroda", "czwartek", "piatek", "sobota", "niedziela"}; 
Console.WriteLine("Ponizej dni tygodnia:");
for (int i=0; i<tydzien.Length; i++){
  Console.WriteLine(tydzien[i]);

}
Console.WriteLine("Koniec");


  }
}